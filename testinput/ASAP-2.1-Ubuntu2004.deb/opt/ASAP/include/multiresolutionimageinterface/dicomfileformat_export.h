
#ifndef DICOMFILEFORMAT_EXPORT_H
#define DICOMFILEFORMAT_EXPORT_H

#ifdef DICOMFILEFORMAT_STATIC_DEFINE
#  define DICOMFILEFORMAT_EXPORT
#  define DICOMFILEFORMAT_NO_EXPORT
#else
#  ifndef DICOMFILEFORMAT_EXPORT
#    ifdef dicomfileformat_EXPORTS
        /* We are building this library */
#      define DICOMFILEFORMAT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define DICOMFILEFORMAT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef DICOMFILEFORMAT_NO_EXPORT
#    define DICOMFILEFORMAT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef DICOMFILEFORMAT_DEPRECATED
#  define DICOMFILEFORMAT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef DICOMFILEFORMAT_DEPRECATED_EXPORT
#  define DICOMFILEFORMAT_DEPRECATED_EXPORT DICOMFILEFORMAT_EXPORT DICOMFILEFORMAT_DEPRECATED
#endif

#ifndef DICOMFILEFORMAT_DEPRECATED_NO_EXPORT
#  define DICOMFILEFORMAT_DEPRECATED_NO_EXPORT DICOMFILEFORMAT_NO_EXPORT DICOMFILEFORMAT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef DICOMFILEFORMAT_NO_DEPRECATED
#    define DICOMFILEFORMAT_NO_DEPRECATED
#  endif
#endif

#endif /* DICOMFILEFORMAT_EXPORT_H */
